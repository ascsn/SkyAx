MODULE staticstep

USE paramr
USE cranking
USE constr
USE dynpar
USE fields
USE observ
USE wavefr
USE levels
USE grid

IMPLICIT REAL(8) (a-h,o-z)
PRIVATE


!*************************************************************************
!  Parameter settings
!*************************************************************************

!  'ifqq' switches to explicit evaluation of <Q*Q> and <QH>
!  and derives the 'QFAC' correction as well as 'qlamb' from it.
!  For details, see SUBROUTINE 'update_lambda()'.
INTEGER,PARAMETER :: ifqq=0

INTEGER,PARAMETER :: ifqqpr=1     ! switch for protocol of <QQ> etc
INTEGER,PARAMETER :: ioccmx=1     ! switch for propagation of occ.number
INTEGER,PARAMETER :: ifvarh=1     ! switch for full variance
INTEGER,PARAMETER :: ifopts=0     ! protocol of optimal stepsize
INTEGER,PARAMETER :: ifcstp=0     ! protocol of constraint step
REAL(8),PARAMETER :: v2lim=1D-7   ! lower limit for inclusion in 'rho' sum


LOGICAL, PARAMETER :: tcoulfold=.false. ! switch for proton folding in Coulomb
LOGICAL, PARAMETER :: texpect=.false.
LOGICAL,SAVE :: tvarfile=.false.
LOGICAL, PARAMETER :: tshiftcm=.true.   ! always shift c.m. to z=0

!     Setting for diagonalization within available states:
!     The 'h-->psi' is stored ion each block misusing the
!     array 'dpsir' from the cranking part.

LOGICAL, PARAMETER :: tdiag2=.true.
LOGICAL, PARAMETER :: ttestdiag=.false.

REAL(8),ALLOCATABLE :: hmatr(:,:),eigvec(:,:)
!REAL(8),POINTER :: hmatr(:,:),eigvec(:,:)        ! restore later
!DIMENSION hmatr(kcrank*npsid,kcrank*npsid)
!EQUIVALENCE (hmatr,qresp)
!DIMENSION eigvec(kcrank*npsid,kcrank*npsid)
!EQUIVALENCE (eigvec,qab01)

! limiting depth of constraining potential for linear constraint
REAL(8), PARAMETER :: vqlimlow=1D0,vqlimup=10D0   


!*************************************************************************
!  Other variables
!*************************************************************************

LOGICAL :: tqq
LOGICAL :: tdiag
INTEGER :: jst,nlo,nhi
REAL(8) :: qlambn,qlstep
REAL(8) :: spevhh(npsid)    ! storage for h*h variance

REAL(8),SAVE :: qc

REAL(8) :: devhh2              ! counter for variance (h*h)
REAL(8) :: hdh                 ! counter for <hD h>
REAL(8) :: hddh                ! counter for <hD Dh>
REAL(8) :: hdhdh               ! counter for <hD h Dh>
REAL(8) :: qh                  ! counter for <Q h>
REAL(8) :: qhdig               ! counter for diagonal part of <Q h>

! The following are already defined in 'm_observ.f90':
!    devh2               ! counter for variance
!    devoc2              ! counter for variance (occ.)
!    devmf2              ! counter for variance (mf)
!    devgap              ! counter for gap equation
!    qdh                 ! counter for <Q Dh>
!    qq                  ! counter for <Q Q>  


PUBLIC sstep

CONTAINS

!-----sstep -----------------------------------------------------------


SUBROUTINE sstep(iter)

!**********************************************************************
!                                                                     *
!        sstep  - subroutine to propagate one gradient iteration      *
!                 step                                                *
!                                                                     *
!**********************************************************************

USE coulomb, ONLY: wcolt
IMPLICIT REAL(8) (a-h,o-z)


INTEGER, INTENT(IN)           :: iter



!----------------------------------------------------------------------

!hmatr(1:kcrank*npsid,1:kcrank*npsid) => qab10
!eigvec(1:kcrank*npsid,1:kcrank*npsid) => qab01
ALLOCATE(hmatr(1:kcrank*npsid,1:kcrank*npsid))


tqq = (ifqq == 1 .OR. ifqqpr == 1)    ! shorthand protocol lambda update
tdiag = tdiag2.AND.(swdiag == 1)      ! pre-diagonalization in sp-space

IF(tdiag .AND. kcrank /= 1)  &
    STOP 'SSTEP: KCRANC=1 needed for pre-diagonalization'

! open protocol files to track variances
IF(tvarfile) THEN
  OPEN(171,FILE='variances1')
  WRITE(171,'(a,600(i2,1pg12.4))')  &
      '#',(mpsi(jst),spenrg(jst),jst=1,nst(1)+nst(2))
  OPEN(172,FILE='variances2')
  WRITE(172,'(a,600(i2,1pg12.4))')  &
      '#',(mpsi(jst),spenrg(jst),jst=1,nst(1)+nst(2))
  tvarfile = .false.
END IF

IF(isym /= 1 .AND. iter > 2) CALL zcm_adjust()    ! update c.m. (asymmetric case)



! optionally compute dynamic damping of constraint using actual density
IF( iter /= 0 .AND. idampc == 1 .AND. iflin /= 1) CALL  dyndamp_constr()


! damp constraint potential for linear constraint
IF( iter /= 0 .AND. idampc == 1 .AND. iflin == 1) CALL  damp_linconstraint()

!     initialize the Coulomb solver for RESPAX
IF((ipair == 9 .OR. ipair == 11) .AND. ilnrsp == 1 .AND. iter == 0) &
      wcoltt(0:nz,0:nr) = wcolt(0:nz,0:nr)


!     initialize accumulators for density, currents, etc
redfac = one-adyrho
rho(0:nz,0:nr,1:2)     = redfac*rho(0:nz,0:nr,1:2)
tau(0:nz,0:nr,1:2)     = redfac*tau(0:nz,0:nr,1:2)
drhols(0:nz,0:nr,1:2)  = redfac*drhols(0:nz,0:nr,1:2)
rholsr(0:nz,0:nr,1:2)  = redfac*rholsr(0:nz,0:nr,1:2)
rholsz(0:nz,0:nr,1:2)  = redfac*rholsz(0:nz,0:nr,1:2)
IF(swicon > oh) rhoti(0:nz,0:nr,1:2) = redfac*rhoti(0:nz,0:nr,1:2)  ! for CHF
IF(ifstab == 1) rhosur(0:nz,0:nr,1:2)=0D0   ! for stabilizing wall

!**********************************************************************
!                                                                     *
!        here starts the big loop over states, sorted in blocks       *
!        of azimuthal angular momenta 'm' and within over             *
!        the states in each block. the wavefunction indices are       *
!        computed and charge,m,z-parity, and occupation               *
!        numbers are indexed                                          *
!                                                                     *
!**********************************************************************


!  initialize accumulators for variances
devh2 = 0D0; devoc2= 0D0; devmf2= 0D0; devhh2= 0D0; devgap= 0D0; 
hdh   = 0D0; hddh  = 0D0; hdhdh = 0D0; 
IF(tqq)  qh    = 0D0;  qdh   = 0D0;  qq    = 0D0;  qhdig = 0D0


DO  im=1,nom         ! loop over all blocks
  nhi=mhi(im)        ! uppermost state for given 'im'
  nlo=mlo(im)        ! lowest state for given 'im''
  nadd=nhi-nlo+1     ! number of states in 'im' block
  kpsic=mim(im)      ! actual 'm' value for 'im,'
  iq=miq(im)         ! actual isospin 'iq' for given 'im'
  IF(itest >= 2)  WRITE(7,'(6(a,i4)/)') 'rank=',mpirank,'mblock=',im,  &
       '          nlo=',nlo,'   nhi=',nhi, '   lz=',kpsic,'   chg=',iq

  
  IF(iter > 0) THEN
    IF(tdiag) dpsir(0:nz,0:nr,1:nsd,nlo:nhi) = psi(0:nz,0:nr,1:nsd,nlo:nhi)
    DO  jst=nlo,nhi
      
!**********************************************************************
!                                                                     *
!        here begins the central piece of the static step:            *
!                                                                     *
!**********************************************************************
      
      
      
      
      ! action of Hamiltonin in wf
      IF(texpect) ebin    = spenrg(jst)
      CALL hpsi(psi(0,0,1,jst),psin,jst)
      IF(tdiag) CALL collmatr(hmatr,psin,nlo,jst,nhi-nlo+1)

      CALL accumulate_variances_1()
        
      ! apply damping
      CALL damnuc(psin,psip,jst)
        
      CALL accumulate_variances_2()        


      ! the key iteration step
      psi(0:nz,0:nr,1:nsd,jst) = psi(0:nz,0:nr,1:nsd,jst)-psip(0:nz,0:nr,1:nsd)



      ! optionally one extra subiteration 
      IF(ABS(itsub)>1) THEN
        STOP " |itsub|>1 not yet possible"
      ELSE IF(ABS(itsub)==1) THEN

        IF(texpect) ebin    = spenrg(jst)
        CALL hpsi(psi(0,0,1,jst),psin,jst)
        IF(tdiag) CALL collmatr(hmatr,psin,nlo,jst,nhi-nlo+1)

        IF(itsub > 0) THEN                                   
          CALL damnuc(psin,psip,jst)
          psi(0:nz,0:nr,1:nsd,jst) = psi(0:nz,0:nr,1:nsd,jst)  &
                                    -x0fac*psip(0:nz,0:nr,1:nsd)
        ELSE                                                      
          psi(0:nz,0:nr,1:nsd,jst) = psi(0:nz,0:nr,1:nsd,jst)  &
                                    -x0fac*psin(0:nz,0:nr,1:nsd)
        END IF
      END IF
        
!      end of inner loop over states within a block of same 'm'
    END DO
    
    IF(tdiag) CALL diag_wf(hmatr,nlo,nhi-nlo+1)
    
!   Schmidt orthonormmalization of the states  ( needed after "diag_wf")
    CALL schmit(psi(0,0,1,nlo),nlo-1,nadd)
    IF(ttestdiag .AND. nhi > nlo) CALL testdiag(hmatr,nlo,nhi-nlo+1)

  END IF
  
!   begin loop to compute the new density and s.p.energies.
!   within a block of same 'm'
  
  DO jst=nlo,nhi
    iq = icharg(jst)
    IF(adyrho*vsqf(jst) > v2lim) THEN
      IF (swicon > oh.AND.iter == 0) THEN
        CALL densit(psi(0,0,1,jst),adyrho*vsqf(jst),jst,  &
                    rho(0,0,iq),tau(0,0,iq),drhols(0,0,iq),  &
                    rholsr(0,0,iq),rholsz(0,0,iq) )
      ELSE IF(swicon > oh.AND.iter > 0.AND.iter <= itcons) THEN
        CALL sdenti(psi(0,0,1,jst),rhoti(0,0,iq),adyrho*vsqf(jst),jst)
      ELSE
        CALL densit(psi(0,0,1,jst),adyrho*vsqf(jst),jst,  &
                    rho(0,0,iq),tau(0,0,iq),drhols(0,0,iq),  &
                    rholsr(0,0,iq),rholsz(0,0,iq) )
      END IF
    END IF
  END DO
  
  
!**********************************************************************
!                                                                     *
!      here ends the first loop over all blocks                       *
!                                                                     *
!**********************************************************************
  
END DO

! finalize variances
IF(ifvarh == 1) THEN
  devh2  = SQRT(ABS(devh2))
  devoc2 = SQRT(ABS(devoc2))
  devmf2 = SQRT(ABS(devmf2))
ELSE
  devmf2 = SQRT(ABS(devmf2))
  devh2  = devmf2
END IF
devhh2 = SQRT(devhh2)
!WRITE(6,*) 'deviations:',devh2,devmf2
!WRITE(7,*) 'deviations:',devh2,devmf2


! some protocol prints
IF(ifopts == 1) THEN
  aopt = (hdh-hdh*hddh)/MAX(hdhdh-hdhdh*hddh,smal)
  WRITE(7,'(a,2g12.4)') ' optimal stepsize=',aopt
  WRITE(6,'(a,2g12.4)') ' optimal stepsize=',aopt
END IF
IF(tqq.AND.(qq == 0.0)) THEN
  WRITE(66,'(a,i4,6g12.4)') 'iter,qh,qdh,qq,qhdig,qh/qq,qlam=',  &
      iter,qh,qdh,qq,qhdig,qq,qlamb
ELSE
  WRITE(66,'(a,i4,6g12.4)') 'iter,qh,qdh,qq,qhdig,qh/qq,qlam=',  &
      iter,qh,qdh,qq,qhdig,qh/qq,qlamb
END IF



!**********************************************************************
!                                                                     *
!   (optional) part for iteration of constraint                       *
!                                                                     *
!**********************************************************************

IF (swicon > oh.AND.iter > 0.AND.iter <= itcons) THEN

! calculation of Q-corrective step and update of Lagrange parameter
  CALL update_lambda()

  
!     prepare stepping factor for quadrupole
  IF(ifqq /= 3) wrk4(0:nz,0:nr) = EXP(-qcorr*qfac(0:nz,0:nr))
  

!**********************************************************************
!                                                                     *
!        second loop over the number of m blocks                      *
!                                                                     *
!**********************************************************************
  
  DO  im=1,nom
    nhi=mhi(im)
    nlo=mlo(im)
    nadd=nhi-nlo+1
    iq=miq(im)


    ! Quadrupole correction and ortho-normalization
    IF(ifqq /= 3) THEN

      DO jst=nlo,nhi
        
        DO is=1,2
          psi(0:nz,0:nr,is,jst) = wrk4(0:nz,0:nr)*psi(0:nz,0:nr,is,jst)
        END DO
        
        IF(icutr /= 0 .OR. icutz /= 0) CALL pronuc(psin,psi(0,0,1,jst),jst)
        
      END DO
      
      CALL schmit(psi(0,0,1,nlo),nlo-1,nadd)
      
    END IF
    
    ! new densities    
    DO jst=nlo,nhi
      iq = icharg(jst)
      IF(adyrho*vsqf(jst) > v2lim)  &
          CALL densit(psi(0,0,1,jst),adyrho*vsqf(jst),jst,  &
          rho(0,0,iq),tau(0,0,iq),drhols(0,0,iq), rholsr(0,0,iq),rholsz(0,0,iq) )
      IF(ifstab == 1) THEN
        width = stwid/SQRT(anumb)
        fac   = EXP(-((spenrg(jst)-fer(iq))/width)**2)
        IF(fac > v2lim) CALL sdenti(psi(0,0,1,jst),rhosur(0,0,iq),fac,jst)
      END IF
    END DO
    
  END DO
!**********************************************************************
!                                                                     *
!        end of 2. loop over the number of m blocks                   *
!                                                                     *
!**********************************************************************

  ! new quadrupole momenta
  CALL obsti(rho,q,qcst,qsq,qsqcst)            
  IF(ifcstp == 1) WRITE(6,'(a,4(1pg12.4))')  &
      ' OBSTI  step: q,qc,q2,qc2=',q,qcst,qsq,qsqcst
  qold  = q
  qc  = qcst
  IF(ifqq == 2) THEN
    qcon   = ABS((q-qsoll)/MAX(varqsq,smal))
  ELSE IF(ifqq == 3) THEN
    qcon   = ABS((qcst-qcstold)/MAX(qtilc2,smal))
    qcstold = qcst
  ELSE
    qcon   = ABS((qcst-qsoll)/MAX(varqsq,smal))
  END IF

  ! test prints
  IF(itest >= 1) THEN
    WRITE(7,'(a,5(1pg10.3))') ' qtil,q=',qtil,q
    WRITE(6,'(a,5(1pg10.3))') ' qtil,qold,q,varqsq,varex=',  &
        qtilc,qold,qc,qsqcst-qc*qc/annum,-0.5*(qc-qtilc)/qcorr
    IF(ifqq == 1) THEN
      varqsc = ABS(qtilc2-qtilc*qtilc/annum)
      varqsq = ABS(qtil2-qtil*qtil/annum)
      WRITE(73,'(1x,8(1pg10.2))')  &
          qtilc,qcst,varqsc,qq,varqsc/qq,qdh/qq,qlcstp,qlcstp*qq/qdh
      WRITE(74,'(1x,8(1pg10.2))')  &
          qtil,q,varqsq,qq,varqsq/qq,qdh/qq,qlstep,qlstep*qq/qdh
      WRITE(6,'(a,5(1pg10.3))') ' qq,qdh,qdh/qq,qlstep,ratio=',  &
          qq,qdh,qdh/qq,qlstep,qlstep*qq/qdh
    ELSE
      WRITE(73,'(1x,8(1pg10.2))') qtilc,qcst,varqsc,0D0,0D0,0D0,qlcstp,0D0
      WRITE(74,'(1x,8(1pg10.2))') qtil,q,varqsq,0D0,0D0,0D0,qlstep,0D0
    END IF
  END IF
  
END IF
!**********************************************************************
!                                                                     *
!     here ends to block for constraint iteration                     *
!                                                                     *
!**********************************************************************


CALL update_occupations()


!**********************************************************************
!                                                                     *
!     new mean-field hamiltonian                                      *
!                                                                     *
!**********************************************************************

!     save coulomb density
IF(tcoulfold) THEN
  CALL protfold(rho(0,0,1),crho)
ELSE
  crho(0:nz,0:nr) = rho(0:nz,0:nr,1)
END IF

IF(itest >= 1 .AND. MOD(iter,iprint) == 0) THEN
  WRITE(7,'(a,i3,a)') ' densities in sstep (iter=',iter,'):'
  CALL testpr(rho,0,nzo,0,nro,'  rho')
  CALL testpr(tau(0,0,2),0,nzo,0,nro,'  tau')
  CALL testpr(tau(0,0,2),0,nzo,0,nro,'  tau')
  IF(t4 /= 0D0) CALL testpr(drhols,0,nzo,0,nro,' drhols')
END IF

! optionally stabilizing potential
IF(ifstab == 1 .AND. iter > 1) THEN
  CALL stapot(wrk1)                  
  IF(iter == itmax) THEN
    CALL testpr(wrk1,0,nz,0,nr,'from STAPOT')
  END IF
END IF

! the new mean fild
CALL mfhmlt(iter)

!NULLIFY(hmatr,eigvec)
DEALLOCATE(hmatr)

RETURN
END SUBROUTINE sstep


SUBROUTINE zcm_adjust()

!  Computes actual c.m. along z-direction and
!  updates constraint field correspondingly.
!  Optionally, it shifts the c.m. to z=0 before all that.

  IF (tshiftcm) THEN
    zcm = zcmobs(rho)
    DO jst=1,nst(1)+nst(2)
      CALL shiftcm(zcm,jst)
    END DO
  END IF
  zcm = zcmobs(rho)
  CALL inicon

END SUBROUTINE zcm_adjust

SUBROUTINE dyndamp_constr()

! Dynamic damping of constraint according to actual density 'rho'.
! The nuclear surface line is defined with respect to a certain critical
! density value. The distance to the surface line is evaluated, and the
! constraint field is attenuated with a Saxon-Woods profile using this
! distance.
! Three ways of defining the distance of the surface are tested:
!   damcst   -- distance of an outer point (rho<rho_critical) is the minimal
!               distance to an inner point (rho>rho_critical) and vice versa.
!   delrmn   -- the surface line is evaluated as r(z) using linear interpolation
!               of density. Then the distance is computed as the shortest distance 
!               to this surface line.
!   damint   -- similar as 'delrmn', but using direct linear interpolation between
!               the gid points.
! The first way in 'damcst' is actually used and stored in the array for constraint.
! The other schemes are evaluated and printed for comparison.
!
! !! NOTE: 
!    This is a routine in development and requires further investigations before
!    it can be used in production runs. Open problems are, e.g., lack of truly
!    variational formulatio (the actual 'rho' is used) and discontinuities due
!    to box interpolation )in 'damcst') and, less so, to linear interpolation.
!
  CALL damcst(iter,rhoswc)
  wrk2(0:nz,0:nr) = rho(0:nz,0:nr,1)+rho(0:nz,0:nr,2)
  CALL delrmn(wrk2,rhoswc,wrk1)       ! distance field now on WRK1
  IF(iter == itmax) THEN
    CALL testpr(wrk2,0,nz,0,nr,'rhoin')
    CALL testpr(distsf,0,nz,0,nr,'distfc')
    CALL testpr(wrk1,0,nz,0,nr,'from DELRMN')
  END IF
!    DO idum=1,1  !   why 10 ?
  CALL damint(wrk2, rhoswc, wrk1)
!    END DO
  IF(iter == itmax) CALL testpr(wrk1,0,nz,0,nr,'from DAMINT')

END SUBROUTINE dyndamp_constr

SUBROUTINE damp_linconstraint()

! Damping of linear constraint by simpy limiting the constraint
! potential from below and from above (see 'vqlimlow', 'vqlimup').

  IF(ABS(qlamb)>1D-4)  THEN
    actlimlow = vqlimlow/qlamb
    actlimup = vqlimup/qlamb
    DO ir=0,nr
      DO iz=0,nz
        IF(qcfac(iz,ir)>12D0) THEN
          qfac(iz,ir) = 12D0
        ELSE IF(qcfac(iz,ir)<12D0) THEN
          qfac(iz,ir) = 12D0
!           IF(qlamb*qcfac(iz,ir)>vqlimup) THEN
!             qfac(iz,ir) = actlimup
!           ELSE IF(qlamb*qcfac(iz,ir)<vqlimlow) THEN
!             qfac(iz,ir) = -actlimlow
        ELSE
          qfac(iz,ir) = qcfac(iz,ir)
        END IF
      END DO
    END DO
    WRITE(*,*) ' qlamb=',qlamb
  ELSE
    qfac=qcfac
  END IF

END SUBROUTINE damp_linconstraint


SUBROUTINE accumulate_variances_1()

! Accumulation of various expectation values and variances
! part 1 = accumulation before wavefunction damping

      

!  s.p. energies and variances
  IF(texpect) THEN
    esub        = wfovlp(psi(0,0,1,jst),psin)
    spenrg2     = wfovlp(psin,psin)
    spevar(jst) = SQRT(ABS(spenrg2-esub*esub))
    spenrg(jst) = esub+ebin
    CALL hpsi(psin,psip,jst)
    spenrg2     = wfovlp(psi(0,0,1,jst),psip)
    devhh2 = devhh2 + ABS(spenrg2-esub*esub)*vsqf(jst)*wate(jst)
    spevhh(jst) = SQRT(ABS(spenrg2-esub*esub))
  END IF
        
!  accumulation of <Qh> and <QQ>    
  IF(tqq)  THEN
    DO is=1,nsd
      psip(0:nz,0:nr,is) = qfac(0:nz,0:nr)*psi(0:nz,0:nr,is,jst)
    END DO
    qq =  vsqf(jst)*wate(jst)*wfovlp(psip,psip) + qq
    qh    =  vsqf(jst)*wate(jst)*wfovlp(psip,psin) + qh
    va    = vsqf(jst)
    ua    = SQRT(one-va)
    va    = SQRT(va)
    qhdig = (ua*ua-va*va)*2.0*ua*va*deltaf(jst) + qhdig
    DO jstp=nlo,nhi
      IF(nparz(1,jst) == nparz(1,jstp)) THEN
        hab    = wfovlp(psi(0,0,1,jstp),psin)
        qab    = wfovlp(psi(0,0,1,jstp),psip)
        vb     = vsqf(jstp)
        ub     = SQRT(one-vb)
        vb     = SQRT(vb)
        offwgt = va*vb*(ua*ub-va*vb)*wate(jst)
        qh     = offwgt*hab*qab + qh
        qq     = offwgt*qab*qab + qq
      END IF
    END DO
  END IF
        
!  accumulate variance of mean-field hamiltonian
  devmf2  = vsqf(jst)*wate(jst)*spevar(jst)**2 + devmf2
  vv2     = vsqf(jst)
  devgap  = wate(jst)* ((spenrg(jst)-fer(iq))*2.0*SQRT(vv2-vv2*vv2)  &
           -gap(iq)*(one-vv2-vv2) ) + devgap
  IF(ifvarh == 1) THEN
    psip(0:nz,0:nr,1:2) = psin(0:nz,0:nr,1:2)
    CALL projec(psip,npar(jst),nlo-1,nhi-nlo+1,offnor)
    devh2  = vsqf(jst)*wate(jst)*wfovlp(psip,psip) + devh2
    devoc2 = vsqf(jst)*wate(jst)*offnor + devoc2
  END IF

END SUBROUTINE accumulate_variances_1

SUBROUTINE accumulate_variances_2()        

! Accumulation of various expectation values and variances
! part 2 = accumulation after wavefunction damping

  IF(tqq)  THEN
    DO is=1,nsd
      psin(0:nz,0:nr,is) = qfac(0:nz,0:nr)*psi(0:nz,0:nr,is,jst)
    END DO
    qdh  = vsqf(jst)*wate(jst)*wfovlp(psip,psin) + qdh
    va   = vsqf(jst)
    ua   = SQRT(1D0-va)
    va   = SQRT(va)
    DO jstp=nlo,nhi
      IF(nparz(1,jst) == nparz(1,jstp)) THEN
        vb     = vsqf(jstp)
        ub     = SQRT(one-vb)
        vb     = SQRT(vb)
        offwgt = va*vb*(ua*ub-va*vb)*wate(jst)
        hab    = wfovlp(psi(0,0,1,jstp),psip)
        qab    = wfovlp(psi(0,0,1,jstp),psin)
        qdh    = offwgt*hab*qab + qdh
      END IF
    END DO
  END IF
        
        
  IF(ifopts == 1) THEN                      ! test
    CALL projec(psip,npar(jst),nlo-1,nhi-nlo+1,offnor)
    hdh   = vsqf(jst)*wate(jst)*wfovlp(psin,psip) + hdh
    hddh  = vsqf(jst)*wate(jst)*wfovlp(psip,psip) + hddh
    CALL hpsi(psip,psin,jst)
    hdhdh = vsqf(jst)*wate(jst)*wfovlp(psin,psip) + hdhdh
  END IF


END SUBROUTINE accumulate_variances_2


SUBROUTINE update_lambda()

!  Calculation of Q-corrective step and update of Lagrange 
!  parameter 'qlmabda'.
!  Various strategies to deduce 'qcorr' and 'qlambda' can be chosen: 
!     ifqq = 0 --> from damped Q and local estimate of Delta Q
!     ifqq = 1 --> difference of damped Q and exact variances of damped Q
!     ifqq = 2 --> from raw Q and local estimate of raw Delta Q
!     ifqq = 3 --> simple 'qlambda' from quadratic constr, no 'qcorr'
!  Most of them are in testing stage.
!  --> Augmented Lagrangian yet to be implemented and tested
  
  CALL obsti(rhoti,qtil,qtilc,qtil2,qtilc2) ! new quadrupole momenta
  IF(ifcstp == 1) WRITE(6,'(a,4(1pg12.4))')  &
      ' OBSTI trial: q,qc,q2,qc2=',qtil,qtilc,qtil2,qtilc2

! direct correction of expectation value of constraint
  x0eff  = x0inv*(one+x0fac*(itsub-1))
  qlcstp = - (MAX(e0inv,one)/x0eff)  &
      *(qtilc-qcst)/(two*ABS(qtilc2-qtilc*qtilc/annum)+d0)
!     &          / adyrho
  qlstep = - (MAX(e0inv,one)/x0eff)  &
      *(qtil-q)/(two*ABS(qtil2-qtil*qtil/annum)+d0)

! update Lagrange parameter 'qlambda'
  IF(ifqq == 1) THEN
    varqsq = qq
    qcorr  = c0*(qtilc-qsoll)/(two*varqsq+d0)
    qlambn = qlamb+qeps*qh/qq
  ELSE IF(ifqq == 0) THEN
    varqsq = ABS(qtilc2-qtilc*qtilc/annum)
    qcorr  = c0*(qtilc-qsoll)/(two*varqsq+d0)
    qlambn = qlamb+qeps*qlcstp
  ELSE IF(ifqq == 3) THEN
    qlambn = -c0*(qtilc-qsoll)/qtilc2
    qlamb  = qlambn
    WRITE(7,'(a,6(1pg12.4))') ' qsoll,qtilc,qtilc2,qlamb,qcon=',  &
        qsoll,qtilc,qtilc2,qlamb,qtilc-qsoll
  ELSE
    varqsq = ABS(qtil2-qtil*qtil/annum)
    qcorr  = c0*(qtil-qsoll)/(two*varqsq+d0)
    qlambn = qlamb+qeps*qlstep
  END IF
!                           limit step in 'qlamb'
  IF(ifqq /= 3) THEN
    IF(itert /= iter .AND. iter < 10 .AND. qlamb /= 0D0) THEN
      qlstep = (qlambn-qlamb)/qlamb
      qlstep = SIGN(MIN(ABS(qlstep),qeps),qlstep)
      qlstep = qlamb*qlstep
      qlamb  = qlstep+qlamb
    ELSE
      qlamb  = qlambn
    END IF
  END IF
  IF(ifcstp == 1) WRITE(6,'(a,4(1pg12.4))')  &
      ' steps: qcorr,qlstep,qlamb=',qcorr,qlstep,qlamb


END SUBROUTINE update_lambda

SUBROUTINE update_occupations()

!
!  calculate occupation numbers and ordering of the levels.
!  iofk is the pointer to the 1 st index of state q        
!

INTEGER :: nsttot         

nsttot=nst(1)+nst(2)


! shift s.p. energies to initialize bubble shape
IF(einitbubble /= 0D0 .AND. iter <= itpini) THEN
  DO jst=1,nst(1)+nst(2)
    spenrg(jst) = spenrg(jst)-einitbubble*mpsi(jst)**2
  END DO
  WRITE(7,*) ' einitbubble=',einitbubble
END IF


! filling approximation 
IF((ipair==-1.AND.iter<=ivs) .OR. (ipair>=0.AND.itert<=itpini)) THEN
  DO iq=1,2
    iofk=iokk(iq)
    CALL vsqtr(vsqf(iofk),wate(iofk),nst(iq),  &
        spenrg(iofk),npart(iq),iorder(iofk))
  END DO
END IF

IF(ipair == 4 .AND. ifocsv == 1) THEN
  DO jst=1,nst(1)+nst(2)
    vsqf(jst) = oc(jst)
  END DO
  WRITE(6,'(a)') ' use fixed VSQF'
ELSE IF(iter == itpfix) THEN
  oc(1:nsttot) = vsqf(1:nsttot)                   ! save status
ELSE IF(iter > itpfix) THEN
  vsqf(1:nsttot) = oc(1:nsttot)                  ! restore
ELSE IF(ipair >= 0.AND.itert >= itpini) THEN
  vsqfol(1:nsttot) = vsqf(1:nsttot)
  ! BCS with constant gap or constant force
  IF(ipair == 0 .OR. ipair == 1 .OR. ipair == 4) THEN
    CALL pairol(spenrg,vsqf,wate,npart(1),nst(1),ggg(1),fer(1),  &
                gap(1),partnm,npiter,ipair,erra,itest-2)
    epair(1) = -gap(1)**2/MAX(ggg(1),1D-20)
    ist2 = nst(1)+1
    CALL pairol(spenrg(ist2),vsqf(ist2),wate(ist2),npart(2),  &
        nst(2),ggg(2),fer(2), gap(2),partnm,npiter,ipair,erra,itest-2)
    epair(2) = -gap(2)**2/MAX(ggg(2),1D-20)
    vsqobs(1:nsttot) = vsqf(1:nsttot)
  ! Lipkin-Nogami BCS with constant gap or constant force
  ELSE IF(ipair == 2 .OR. ipair == 3) THEN
    IF(iter > 40) THEN
      rhoscp = semrho(fer(1),pot(0,0,1),bmass(0,0,1))
      ggp  = gavrg(3-ipair,npart(1),npart(2),1,rhoscp,1,numsta(1),  &
          effmas,0.58*0.960D0)              ! estimate surfp=0.96
      ggg(1) = ggp
      rhoscn = semrho(fer(2),pot(0,0,2),bmass(0,0,2))
      ggn  = gavrg(3-ipair,npart(1),npart(2),0,rhoscn,1,numsta(2),  &
          effmas,0.58*0.960D0)              ! estimate surfp=0.96
      ggg(2) = ggn
      WRITE(7,'(a,i4,a,4g12.4)') ' iter=',iter,  &
          ' rhoscp,rhoscn,ggp,ggn=',rhoscp,rhoscn,ggp,ggn
    END IF
    IF(ilnrsp == 1) THEN
      CALL respax(iter)
      IF(itest > 0) WRITE(7,'(a,4g12.4)')  &
          ' RESPAX: rspln(1/2),suv2r2(1/2)=',rspln,suv2rs
    END IF
    CALL bcslip(spenrg,watep,1,nst(1),npart(1),ggg(1),gap(1),  &
        fer(1),fer2(1),vsqf,vsqobs, epsimp,epair(1),entotp,rspln(1),suv2rs(1),  &
        ipair-2,itest-1)
    ist2 = nst(1)+1
    CALL bcslip(spenrg(ist2),watep(ist2),1,nst(2),npart(2),ggg(2),  &
        gap(2),fer(2),fer2(2),vsqf(ist2),vsqobs(ist2),  &
        epsimp,epair(2),entotp,rspln(2),suv2rs(2), ipair-2,itest-1)
  ! BCS with zero-range pairing functional
  ELSE IF(ipair == 5 .OR. ipair == 7 .OR. ipair == 9  &
        .OR. ipair == 11) THEN
    IF(itert < 1*itpini) THEN
      gap(1) = 11.2 / SQRT(one*(npart(1)+npart(2)))
      CALL pairol(spenrg,vsqf,wate,npart(1),nst(1),ggg(1),fer(1),  &
          gap(1),partnm,npiter,0,erra,itest-2)
      epair(1) = -gap(1)**2/MAX(ggg(1),1D-20)
      ist2 = nst(1)+1
      gap(2) = gap(1)
      CALL pairol(spenrg(ist2),vsqf(ist2),wate(ist2),npart(2),  &
          nst(2),ggg(2),fer(2), gap(2),partnm,npiter,0,erra,itest-2)
      epair(2) = -gap(2)**2/MAX(ggg(2),1D-20)
    ELSE
      CALL hfbpot(wrk1)
      IF((ipair == 9 .OR. ipair == 11).AND. ilnrsp == 1) THEN
        CALL respax(iter)
        IF(itest > 0) WRITE(7,'(a,4g12.4)')  &
            ' RESPAX: rspln(1/2),suv2r2(1/2)=',rspln,suv2rs
      END IF
      itest = -1
      CALL pairdn(spenrg,deltaf,vsqf, wate,wtpair,one*npart(1),  &
          fer(1),epair(1),gap(1),ggg(1),feradd(1),  &
          nst(1),nst(1),npiter,ipair,0,istblo,erra,itest-1)
      ist2 = nst(1)+1
      CALL pairdn(spenrg(ist2),deltaf(ist2),vsqf(ist2),wate(ist2),  &
          wtpair(ist2),one*npart(2), fer(2),epair(2),gap(2),ggg(2),feradd(2),  &
          nst(2),nst(2),npiter,ipair,nst(1),istblo-nst(1), erra,itest-1)
    END IF
    vsqobs(1:nsttot) = vsqf(1:nsttot)
  ELSE
    STOP ' ipair outside -1..4 or 5, 7, 9 or 11 not active'
  END IF

  ! mixing old and new occupations
  IF(itert > itpini) THEN
  !                                      maximum distance in 'vsqf'
    IF(ioccmx == 1) THEN
      distmx = 0D0
      DO jst=1,nst(1)+nst(2)
        distmx = MAX(ABS(vsqf(jst)-vsqfol(jst)),distmx)
      END DO
      distmx = MAX(addocc,distmx)
      addact = addocc/distmx
    ELSE
      addact = addocc
    END IF
    conocc = one-addact
    DO jst=1,nst(1)+nst(2)
      vsqf(jst)   = addact*vsqf(jst)+conocc*vsqfol(jst)
    END DO
    ! compute pairing energies from gaps and occupations
    ! (not best choice  --> replace by direct integration)
    IF(ipair >= 5) THEN
      epairp = 0.0
      epairn = 0.0
      DO na=1,nst(1)+nst(2)
        v2     = vsqf(na)
        deltaa = deltaf(na)*wtpair(na)
        vol    = 0.5*wate(na)*SQRT(MAX(v2-v2*v2,smal))
        IF(na <= nst(1)) THEN
          epairp = vol*deltaa + epairp
        ELSE
          epairn = vol*deltaa + epairn
        END IF
      END DO
      epair(1) = epairp
      epair(2) = epairn
    END IF
  END IF
END IF

END SUBROUTINE update_occupations

! This routine is obsolete because we can compute optionally the Hamiltonian
! matrix and print it.
!
! SUBROUTINE test_hamiltonian_matrix()
! 
! !        testprint of hamiltonian overlap.
! !        note that the states up to 'jst-1' have already been
! !        modfied such that only the upper right block of the
! !        emerging h-matrix can be trusted.
!         IF(itest >= 2 .AND. MOD(iter,iprint) == 0     &
!               .AND. iters == 1) THEN                
!           DO jstp=nlo,nhi
!             IF(nparz(1,jst) == nparz(1,jstp)) THEN
!               wrk1(jstp,0) = wfovlp(psi(0,0,1,jstp),psin)
!             ELSE
!               wrk1(jstp,0) = 0D0
!             END IF
!           END DO
!           WRITE(7,'(3(a,i3),a,10g11.3,10(/20x,10g11.3))')  &
!               '<',nlo,'...',nhi,'|t|',jst,'>=', (wrk1(jstp,0),jstp=nlo,nhi)
!         END IF
! 
! END SUBROUTINE test_hamiltonian_matrix()

END MODULE staticstep
